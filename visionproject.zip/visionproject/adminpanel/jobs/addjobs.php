<?php
// Include your DB connection
require_once 'connection/connection.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $client_id = $_POST['client_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $budget = $_POST['budget'];
    $status = $_POST['status'];
    $created_at = date('Y-m-d H:i:s'); // current timestamp
    $deadline = $_POST['deadline'];

    $stmt = $pdo->prepare("INSERT INTO jobs (client_id, title, description, budget, status, created_at, deadline) 
                           VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$client_id, $title, $description, $budget, $status, $created_at, $deadline]);

    echo "<div class='alert alert-success'>Job added successfully.</div>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Job</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow rounded-4">
        <div class="card-header bg-primary text-white rounded-top-4">
            <h4 class="mb-0">Add New Job</h4>
        </div>
        <div class="card-body">
            <form method="POST" action="">

                <div class="mb-3">
                    <label for="client_id" class="form-label">Client ID</label>
                    <input type="number" name="client_id" id="client_id" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="title" class="form-label">Job Title</label>
                    <input type="text" name="title" id="title" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Job Description</label>
                    <textarea name="description" id="description" class="form-control" rows="4" required></textarea>
                </div>

                <div class="mb-3">
                    <label for="budget" class="form-label">Budget (USD)</label>
                    <input type="number" name="budget" id="budget" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select name="status" id="status" class="form-select" required>
                        <option value="open">Open</option>
                        <option value="in_progress">In Progress</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="deadline" class="form-label">Deadline</label>
                    <input type="date" name="deadline" id="deadline" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-success">Add Job</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>
