<?php
define('dns','mysql:host=localhost;dbname=freelancer_arena');
define('username','root');
define('password','');

try {
    $connect = new PDO(dns,username,password);
} catch (Exception $error) {
    echo $error->getMessage();
}

?>