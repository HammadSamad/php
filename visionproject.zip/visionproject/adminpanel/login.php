<?php
 session_name('adminPanel');
session_start();

require "connection/connection.php";


if(isset($_SESSION['apUserId']))
{
	header("location:index.php");
}


if (isset($_POST['btn'])) {

	$email = $_POST['email'];
	$password = $_POST['password'];
	

	$loginQuery = "SELECT * FROM users WHERE email = :email";
	$loginPrepare = $connect->prepare($loginQuery);
	$loginPrepare->bindParam(':email', $email);
	$loginPrepare->execute();
	$userExist = $loginPrepare->fetch(PDO::FETCH_ASSOC);
	if ($userExist) {



		if(password_verify($password, $userExist['password_hash']))
		// if($password === $userExist['password_hash'])
		{
			$_SESSION['apUserId'] = $userExist['user_id'];
			$_SESSION['apUsername'] = $userExist['username'];
			$_SESSION['email'] = $userExist['user_email'];
            $_SESSION['roleId'] = $userExist['role_id'];

			echo "<script>alert('Login Successfull')</script>";
			header("location: index.php");
		}	
		else {
			echo "<script>alert('Wrong password')</script>";
		}




	} 
	else {
		echo "<script>alert('Email is invalid')</script>";
	}
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login | KaiAdmin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- KaiAdmin CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="icon" href="assets/images/favicon.png">
</head>

<body class="d-flex align-items-center bg-light justify-content-center" style="min-height: 100vh;">

    <div class="auth-box bg-white p-4 shadow rounded" style="width: 100%; max-width: 400px;">
        <div class="text-center mb-4">
            <img src="assets/img/kaiadmin/logo_dark.svg" alt="KaiAdmin Logo" width="200">
            <h4 class="mt-2">Welcome</h4>
            <p class="text-muted small">Sign in to your freelancer panel</p>
        </div>

        <form method="POST">
            <div class="form-group mb-3">
                <label>Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
            </div>

            <div class="form-group mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
            </div>

            <div class="d-grid mb-3">
                <button type="submit" name="btn" class="btn btn-primary btn-block">Login</button>
            </div>

            <div class="text-center">
                <p class="small">Don't have an account? <a href="registration.php">Register here</a></p>
            </div>
        </form>
    </div>

</body>

</html>