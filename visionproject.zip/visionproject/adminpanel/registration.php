<?php
    require "connection/connection.php";
?>
<?php
    if(isset($_POST['btn']))
    {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        $passwordHash = password_hash($password,PASSWORD_BCRYPT);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register | KaiAdmin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- KaiAdmin CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="icon" href="assets/images/favicon.png">
</head>
<body class="d-flex align-items-center bg-light justify-content-center" style="min-height: 100vh;">

    <div class="auth-box bg-white p-4 shadow rounded" style="width: 100%; max-width: 450px;">
        <div class="text-center mb-4">
            <img src="assets/img/kaiadmin/logo_dark.svg" alt="KaiAdmin Logo" width="200">
            <h4 class="mt-2">Create Account</h4>
            <p class="text-muted small">Start your journey with KaiAdmin</p>
        </div>

        <form action="registration.php" method="POST">
            <div class="form-group mb-3">
                <label>Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>

            <div class="form-group mb-3">
                <label>Email Address</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="form-group mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <div class="d-grid mb-3">
                <button type="submit" name="btn" class="btn btn-primary btn-block">Register</button>
            </div>

            <div class="text-center">
                <p class="small">Already have an account? <a href="login.php">Login here</a></p>
            </div>
        </form>
    </div>

</body>
</html>
